# Sprint 7 — Correctif affichage mobile

Trois améliorations pour l'usage sur téléphone (l'usage principal de l'app).

## Ce qui est corrigé

### 1. Barre du bas : les 7 sections sont visibles
Avant, seules 5 sections sur 7 s'affichaient (Réclamations et Historique
étaient coupées). Désormais, **les 7 sections tiennent sur la barre** :
Accueil, Finances, Projets, Réunions, Annonces, Récla., Historique.
Icônes et libellés légèrement réduits, espacement optimisé. Sur un iPhone
standard, chaque bouton fait ~53px de large — confortable au toucher.

### 2. Cloche de notifications lisible en portrait
Avant, le menu de la cloche débordait hors de l'écran en mode portrait
(il fallait basculer en paysage). Maintenant, sur mobile, le panneau
s'affiche **en pleine largeur** sous l'en-tête, avec un fond pour fermer
d'un tap. Sur ordinateur, il reste un menu déroulant classique.

### 3. Tableau de bord : plus de chevauchement
Sur la carte « Prochaine assemblée générale », le libellé et la valeur se
chevauchaient. Les textes sont raccourcis (« Dans X jours ») et alignés
proprement, sans collision.

## Installation

Décompressez et écrasez le dossier `C:\Users\brahi\Desktop\Syndic`.
Pas de `npm install` (aucune nouvelle dépendance), pas de SQL.

```powershell
npm run dev
```

Puis poussez sur GitHub pour mettre à jour la version en ligne :

```powershell
git add .
git commit -m "Correctif affichage mobile"
git push
```

Vercel redéploiera automatiquement en 1-2 minutes. Rechargez l'app sur
votre téléphone (videz le cache si besoin, ou rouvrez l'app installée).

## À vérifier sur le téléphone

- [ ] La barre du bas montre bien les 7 sections, toutes tappables
- [ ] Réclamations et Historique sont accessibles depuis la barre
- [ ] La cloche s'ouvre en portrait et le contenu est lisible
- [ ] Le tableau de bord n'a plus de texte qui se chevauche
- [ ] L'ensemble reste fluide et lisible

## Note

Si l'app installée sur l'écran d'accueil ne se met pas à jour tout de
suite après le redéploiement, c'est le cache du service worker. Fermez-la
complètement et rouvrez-la, ou supprimez puis réinstallez le raccourci.
Le service worker est configuré en « autoUpdate », donc la mise à jour
arrive automatiquement au bout de quelques secondes / au prochain lancement.
